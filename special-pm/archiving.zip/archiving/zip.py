import zipfile
import os

def extract(zip, to):
    with zipfile.ZipFile(zip, 'r') as zfile:
        zfile.extractall(to)
def create(zip, files):
    prg = zipfile.ZipFile(zip, mode="w")
    for name in files:
        prg.write(name, name)
        prg.close()
def getfiles(zip):
    with zipfile.ZipFile(zip) as zf:
        for name in zf.namelist():
            print(name)
