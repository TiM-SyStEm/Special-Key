import accessify


class Character:
    def isWhitespace(current):
        if len(current) != 1:
            print("Invalid char!")
            quit(65)
        # END BLOCK

        if current == ' ':
            return True
        # END BLOCK

        else:
            return False
        # END BLOCK

    # END BLOCK

    def isDigit(current):
        if len(current) != 1:
            print("Invalid char!")
            quit(65)
        # END BLOCK

        if current.isdigit():
            return True
        # END BLOCK

        else:
            return False
        # END BLOCK

    # END BLOCK

    def isLetter(current):
        if len(current) != 1:
            print("Invalid char!")
            quit(65)
        # END BLOCK

        if current.isalpha():
            return True
        # END BLOCK

    # END BLOCK

    def isUpperCase(current):
        if len(current) != 1:
            print("Invalid char!")
            quit(65)
        # END BLOCK

        if current.isupper():
            return True

        # END BLOCK

        else:
            return False
        # END BLOCK

    # END BLOCK

    def isLowerCase(current):
        if len(current) != 1:
            print("Invalid char!")
            quit(65)
        # END BLOCK

        if current.islower():
            return True
        # END BLOCK

        else:
            return False
        # END BLOCK

    # END BLOCK

    def whitespace():
        return ' '

    # END BLOCK

    def toLowerCase(current):
        if len(current) != 1:
            print("Invalid char!")
            quit(65)
        # END BLOCK

        return current.lower()

    # END BLOCK

    def toUpperCase(current):
        if len(current) != 1:
            print("Invalid char!")
            quit(65)
        # END BLOCK

        return current.upper()
    # END BLOCK


# END BLOCK


class String:
    def charAt(string, index):
        if type(index) is not int:
            print("Index must be integer!")
        # END BLOCK

        return string[index]

    # END BLOCK

    def length(string):
        return len(str(string))

    # END BLOCK

    def indexOf(string, indx):
        return string.index(indx)

    # END BLOCK

    def cut(string, start, end):
        return string[start:end]

        # END BLOCK

    def swapCase(string):
        return string.swapcase()

    # END BLOCK

    def title(string):
        return string.title()

    # END BLOCK

    def trip(string, char):
        return string.strip(char)

    # END BLOCK

    def equals(string, string2):
        if string == string2:
            return True
        # END BLOCK
        else:
            return False
        # END BLOCK

    # END BLOCK

    def isUpperCase(current):
        if current.isupper():
            return True
        # END BLOCK
        else:
            return False
        # END BLOCK

    # END BLOCK

    def isLowerCase(current):
        if current.islower():
            return True
        # END BLOCK
        else:
            return False
        # END BLOCK

    # END BLOCK

    def toLowerCase(current):
        return current.lower()

    # END BLOCK

    def toUpperCase(current):
        return current.upper()

    # END BLOCK

    def contains(string, char):
        if string.find(char) == -1:
            return False
        # END BLOCK
        else:
            return True
        # END BLOCK
    # END BLOCK


# END BLOCK

class StringBuilder:
    value = []

    def __init__(self):
        self.value = []

    # END BLOCK

    def add(self, string):
        self.value.append(string)

    # END BLOCK

    def delete(self, index):
        self.value.pop(index)

    # END BLOCK

    def clear(self):
        self.value.clear()

    # END BLOCK

    def deleteByRange(start, end):
        del self.value[start:end]

        # END BLOCK

        def pop(self):
            self.value.pop(len(self.value) - 1)

        # END BLOCK

        def length(self):
            return str(len(self.value))

        # END BLOCK

        def lengthAsString(self):
            return "length - " + str(self.length())

        # END BLOCK

        def string(self):
            return ''.join(self.value)
        # END BLOCK

    # END BLOCK


# END BLOCK
class HexStrings:

    def toHex(number):
        return hex(number)

    # END BLOCK

    def fromHex(string_hex):
        return int(string_hex, 16)
    # END BLOCK

# END BLOCK
